from heuristic import *
import copy

VAL = 100000

def Make_Move(Return_Board, index, color): #Computes the move, inputed by the index argument, by the player indentified by the color argument
    for i in range(5, -1, -1):
        if(Return_Board.Grid[i][index] == 'X'):
            Return_Board.Grid[i][index] = color
            return
    print("You should not be here")


def reverse_color(color):
    if(color == 'R'):
        return('B')
    else:
        return('R')

def call_alpha_beta(game, color, depth):
    if(color == 'R'):
        maxscore = -VAL
    else:
        maxscore = VAL
    best_move = -1
    possiblemoves = [i for i in range(7) if game.Grid[0][i] == 'X']
    for x in possiblemoves:
        temp_game = copy.deepcopy(game)
        Make_Move(temp_game, x, color)
        score = alpha_beta(temp_game, True, depth, reverse_color(color), -VAL, VAL)
        print(score)
        if(color == 'R'):
            if(maxscore < score):
                maxscore = score
                best_move = x 
        else:
            if(maxscore > score):
                maxscore = score
                best_move = x
    return best_move

def alpha_beta(game, maxPlayer, cdepth, color, alpha, beta):
    if cdepth == 0 or Game_is_Over(game, 'R') or Game_is_Over(game, 'L'):
        return Total_Value(game)
    elif(maxPlayer):
        maxV = -VAL
        possiblemoves = [i for i in range(7) if game.Grid[0][i] == 'X']
        for i in possiblemoves:
            temp_game = copy.deepcopy(game)
            Make_Move(temp_game, i, color)
            eva = alpha_beta(temp_game, False, cdepth-1, reverse_color(color), alpha, beta)
            maxV = max(maxV, eva)
            alpha = max(maxV, alpha)
            if (beta <= alpha):
                break
        return maxV
    else:
        minV = VAL
        possiblemoves = [i for i in range(7) if game.Grid[0][i] == 'X']
        for i in possiblemoves:
            temp_game = copy.deepcopy(game)
            Make_Move(temp_game, i, color)
            eva = alpha_beta(temp_game, True, cdepth-1, reverse_color(color), alpha, beta)
            minV = min(minV, eva)
            beta = min(minV, beta)
            if (beta <= alpha):
                break
        return minV 

""" A implementacao do alpha beta nao esta completa na versao zip, faltou modificar a main
    e fazer os imports devidos. No jupyter notebook esta 100% implementado """